
// This file is no longer needed as SSE functionality has been removed

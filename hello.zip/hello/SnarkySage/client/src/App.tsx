import { useState, useEffect } from 'react';
import { Route, Switch, useLocation } from 'wouter';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import Sidebar from '@/components/Sidebar';
import Chat from '@/pages/chat';
import NotFound from '@/pages/not-found';
import LoginPage from '@/pages/login';
import PrivacyPolicyModal from '@/components/PrivacyPolicyModal';
import SettingsModal from '@/components/SettingsModal';
import { useToast } from '@/hooks/use-toast';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
    },
  },
});

interface User {
  id: string;
  username: string;
  email: string;
  profilePicture?: string;
  privacyPolicyAccepted?: string | null;
  isGuest?: boolean; // Added for guest identification
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [isAuthenticated, setIsAuthenticated] = useState(false); // State to track authentication

  // Always show login page - no auto-login
  useEffect(() => {
    // Clear any existing auth data to force login
    localStorage.removeItem('auth_token');
    localStorage.removeItem('guest_user');
    setIsLoading(false);
  }, []);

  const handleLogin = (token: string | null, userData: User) => {
    console.log('handleLogin called with userData:', userData);
    if (token) {
      localStorage.setItem('auth_token', token);
    }
    if (userData.profilePicture) {
      console.log('Storing profile picture:', userData.profilePicture);
      localStorage.setItem('user_profile_picture', userData.profilePicture);
    } else {
      console.log('No profile picture in userData');
    }
    setUser(userData);
    setIsAuthenticated(true); // Set authenticated state

    // Check if privacy policy needs to be shown (skip for guest users)
    if (!userData.privacyPolicyAccepted && !userData.isGuest) {
      setShowPrivacyModal(true);
    } else {
      navigate('/');
    }
  };

  const handleGuestLogin = () => {
    const guestUser: User = {
      id: 'guest-' + Date.now(),
      username: 'Guest User',
      email: 'guest@saikaki.ai',
      isGuest: true,
      privacyPolicyAccepted: new Date().toISOString() // Guests auto-accept
    };
    localStorage.setItem('guest_user', JSON.stringify(guestUser));
    setUser(guestUser);
    setIsAuthenticated(true);
    navigate('/');
  };

  const handleLogout = () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('guest_user'); // Clear guest data
    setUser(null);
    setIsAuthenticated(false); // Set unauthenticated state
    setCurrentSessionId(null);
    navigate('/login');

    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
  };

  const handlePrivacyAccept = async () => {
    if (user?.isGuest) { // Guests don't need to accept privacy policy in the same way
      setShowPrivacyModal(false);
      navigate('/');
      return;
    }

    try {
      const token = localStorage.getItem('auth_token');
      await fetch('/api/auth/privacy-accepted', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      setUser(prev => prev ? { ...prev, privacyPolicyAccepted: new Date().toISOString() } : null);
      setShowPrivacyModal(false);
      navigate('/');
    } catch (error) {
      console.error('Failed to save privacy acceptance:', error);
    }
  };

  const handleNewChat = () => {
    setCurrentSessionId(null);
    navigate('/');
  };

  const handleSessionSelect = (sessionId: string) => {
    setCurrentSessionId(sessionId);
    navigate('/');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-dark-bg">
        <div className="text-text-primary">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) { // Render login page if not authenticated
    return (
      <QueryClientProvider client={queryClient}>
        <LoginPage onLogin={handleLogin} onGuestLogin={handleGuestLogin} />
        <Toaster />
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex h-screen bg-dark-bg text-text-primary">
        <Sidebar
          currentSessionId={currentSessionId}
          onSessionSelect={handleSessionSelect}
          onNewChat={handleNewChat}
          onSettingsClick={() => setShowSettings(true)}
          user={user}
        />

        <main className="flex-1 flex flex-col">
          <Switch>
            <Route path="/">
              <Chat
                currentSessionId={currentSessionId}
                onSessionCreated={setCurrentSessionId}
                isGuest={user?.isGuest} // Pass guest status to Chat component
              />
            </Route>
            <Route>
              <NotFound />
            </Route>
          </Switch>
        </main>

        <SettingsModal
          isOpen={showSettings}
          onClose={() => setShowSettings(false)}
          user={user}
          onLogout={handleLogout}
          onPrivacyClick={() => setShowPrivacyModal(true)}
        />

        <PrivacyPolicyModal
          isOpen={showPrivacyModal}
          onAccept={handlePrivacyAccept}
          onClose={() => setShowPrivacyModal(false)}
        />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X, Settings, MapPin, MessageSquare, Shield, User, LogOut } from 'lucide-react';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import PrivacyPolicyModal from './PrivacyPolicyModal';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: {
    id: string;
    username: string;
    email: string;
    profilePicture?: string;
    privacyPolicyAccepted?: string | null;
  };
  onLogout: () => void;
  onPrivacyClick: () => void;
}

export default function SettingsModal({ 
  isOpen, 
  onClose, 
  user, 
  onLogout, 
  onPrivacyClick 
}: SettingsModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Delete all chats mutation
  const deleteAllChatsMutation = useMutation({
    mutationFn: async () => {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/chat/sessions', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error('Failed to delete all chats');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/sessions'] });
      toast({
        title: "All Chats Deleted",
        description: "Your chat history has been cleared",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete chats",
        variant: "destructive",
      });
    }
  });

  // Clear privacy policy acceptance
  const clearPrivacyMutation = useMutation({
    mutationFn: async () => {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/auth/privacy-accepted', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error('Failed to clear privacy acceptance');
    },
    onSuccess: () => {
      toast({
        title: "Privacy Acceptance Cleared",
        description: "You'll be asked to accept the privacy policy again on next login",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to clear privacy acceptance",
        variant: "destructive",
      });
    }
  });

  const exportAllChats = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const sessionsResponse = await fetch('/api/chat/sessions', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!sessionsResponse.ok) throw new Error('Failed to fetch sessions');
      const sessions = await sessionsResponse.json();

      const exportData = {
        timestamp: new Date().toISOString(),
        user: user.email,
        sessions: sessions
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `sai-kaki-chats-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Chats Exported",
        description: "Your chat history has been downloaded",
      });
    } catch (error) {
      console.error('Export failed:', error);
      toast({
        title: "Export Failed",
        description: "Could not export chats",
        variant: "destructive",
      });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-gray-300 rounded-2xl max-w-md w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 md:p-6 border-b border-gray-300">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
              <Settings className="text-white h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Settings</h2>
              <p className="text-sm text-gray-600">Manage your preferences</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="p-2 hover:bg-gray-100 text-gray-600 hover:text-gray-900"
            data-testid="button-close-settings"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-4 md:p-6 space-y-6">
          {/* User Account */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <User className="h-5 w-5 mr-2" />
              Account
            </h3>
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
              <div className="flex items-center space-x-3">
                <img 
                  src={user.profilePicture || localStorage.getItem('user_profile_picture') || '/guest-profile-new.png'} 
                  alt={user.username || 'User'}
                  className="w-12 h-12 rounded-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    // Try guest-profile.png as fallback first
                    if (target.src.includes('guest-profile-new.png')) {
                      target.src = '/guest-profile.png';
                    } else if (target.src.includes('guest-profile.png')) {
                      // If both guest profile images fail, use SVG fallback
                      target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Ccircle cx='24' cy='24' r='24' fill='%2306b6d4'/%3E%3Ctext x='24' y='28' text-anchor='middle' fill='white' font-size='16' font-weight='bold'%3EUser%3C/text%3E%3C/svg%3E";
                    }
                  }}
                />
                <div>
                  <div className="font-medium text-gray-900">{user.username}</div>
                  <div className="text-sm text-gray-600">{user.email}</div>
                </div>
              </div>
            </div>
            <Button
              onClick={onLogout}
              variant="outline"
              className="w-full justify-start border-red-600 text-red-500 hover:text-white hover:bg-red-600"
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>

          {/* Chat Management */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <MessageSquare className="h-5 w-5 mr-2" />
              Chat Management
            </h3>
            <div className="space-y-2">
              <Button
                onClick={exportAllChats}
                variant="outline"
                className="w-full justify-start border-gray-300 text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                data-testid="button-export-chats"
              >
                Export All Chats
              </Button>
              <Button
                onClick={() => deleteAllChatsMutation.mutate()}
                variant="outline"
                className="w-full justify-start border-red-600 text-red-500 hover:text-white hover:bg-red-600"
                data-testid="button-clear-all-chats"
                disabled={deleteAllChatsMutation.isPending}
              >
                {deleteAllChatsMutation.isPending ? 'Deleting...' : 'Delete All Chats'}
              </Button>
            </div>
          </div>

          {/* Privacy & Data */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Privacy & Data
            </h3>
            <div className="space-y-2">
              <Button
                onClick={onPrivacyClick}
                variant="outline"
                className="w-full justify-start border-gray-300 text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                data-testid="button-view-privacy"
              >
                View Privacy Policy
              </Button>
              <Button
                onClick={() => clearPrivacyMutation.mutate()}
                variant="outline"
                className="w-full justify-start border-gray-300 text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                data-testid="button-clear-privacy"
                disabled={clearPrivacyMutation.isPending}
              >
                {clearPrivacyMutation.isPending ? 'Clearing...' : 'Reset Privacy Acceptance'}
              </Button>
            </div>
            {user.privacyPolicyAccepted && (
              <div className="text-xs text-gray-600">
                Privacy policy accepted on {new Date(user.privacyPolicyAccepted).toLocaleDateString()}
              </div>
            )}
          </div>

          {/* Location Settings */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <MapPin className="h-5 w-5 mr-2" />
              Location Services
            </h3>
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
              <p className="text-sm text-gray-700">
                Location access is automatically requested when needed for location-based queries 
                (e.g., "nearest McDonald's"). Your precise location is only used temporarily and 
                never stored permanently.
              </p>
            </div>
          </div>

          {/* App Info */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium text-gray-900">About</h3>
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
              <p className="text-sm text-gray-700">
                <strong>Sai Kaki AI Assistant</strong><br />
                Version 0.1<br />
                AI with attitude, real-time data, and chess capabilities
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
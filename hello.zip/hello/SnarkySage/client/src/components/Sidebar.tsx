import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Plus, 
  MessageSquare, 
  Trash2, 
  Download, 
  Settings, 
  ChevronLeft, 
  ChevronRight,
  Search,
  User,
  Menu
} from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Dialog, DialogContent, DialogTrigger, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import type { ChatSession } from '@shared/schema';

interface SidebarProps {
  currentSessionId: string | null;
  onSessionSelect: (sessionId: string) => void;
  onNewChat: () => void;
  onSettingsClick: () => void;
  user: {
    id: string;
    username: string;
    email: string;
    profilePicture?: string;
  };
  className?: string;
}

function SidebarContent({ 
  currentSessionId, 
  onSessionSelect, 
  onNewChat, 
  onSettingsClick,
  user,
  isCollapsed,
  setIsCollapsed,
  onMobileClose
}: SidebarProps & { 
  isCollapsed: boolean; 
  setIsCollapsed: (collapsed: boolean) => void;
  onMobileClose?: () => void;
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();

  // Fetch chat sessions
  const { data: sessions = [] } = useQuery({
    queryKey: ['/api/chat/sessions'],
    queryFn: async () => {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/chat/sessions', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch sessions');
      return response.json();
    }
  });

  // Filter sessions based on search query
  const filteredSessions = sessions.filter((session: ChatSession) =>
    session.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const displayedSessions = filteredSessions.slice().reverse();

  // Delete session mutation
  const deleteSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      const token = localStorage.getItem('auth_token');
      const response = await fetch(`/api/chat/sessions/${sessionId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error('Failed to delete session');
    },
    onSuccess: (_, sessionId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/sessions'] });
      if (currentSessionId === sessionId) {
        onNewChat();
      }
      toast({
        title: "Chat Deleted",
        description: "Chat removed from history",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete chat",
        variant: "destructive",
      });
    }
  });

  // Rename session mutation
  const renameSessionMutation = useMutation({
    mutationFn: async ({ sessionId, title }: { sessionId: string; title: string }) => {
      const token = localStorage.getItem('auth_token');
      const response = await fetch(`/api/chat/sessions/${sessionId}/title`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title })
      });
      if (!response.ok) throw new Error('Failed to rename session');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/sessions'] });
      setEditingSessionId(null);
      setEditingTitle('');
      toast({
        title: "Chat Renamed",
        description: "Chat title updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to rename chat",
        variant: "destructive",
      });
    }
  });

  // Download chat function
  const downloadChat = async (sessionId: string, title: string) => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch(`/api/chat/sessions/${sessionId}/messages`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch messages');
      const messages = await response.json();

      const chatContent = messages.map((msg: any) => 
        `${msg.role === 'user' ? 'You' : 'Sai Kaki'}: ${msg.content}`
      ).join('\n\n');

      const blob = new Blob([chatContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${title || 'Chat'}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Chat Downloaded",
        description: "Chat saved to your device",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Could not download chat",
        variant: "destructive",
      });
    }
  };

  const formatChatTitle = (title: string) => {
    if (title.length > 20) {
      return title.substring(0, 20) + '...';
    }
    return title;
  };

  const formatDate = (date: string | null | undefined) => {
    if (!date) return 'Recently';
    const d = new Date(date);
    if (isNaN(d.getTime())) return 'Recently';

    const now = new Date();
    const diffTime = Math.abs(now.getTime() - d.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return 'Today';
    if (diffDays === 2) return 'Yesterday';
    if (diffDays <= 7) return `${diffDays} days ago`;
    return d.toLocaleDateString();
  };

  const handleTitleClick = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(session.id);
    setEditingTitle(session.title);
  };

  const handleTitleSubmit = (sessionId: string) => {
    if (editingTitle.trim() && editingTitle.trim() !== sessions.find(s => s.id === sessionId)?.title) {
      renameSessionMutation.mutate({ sessionId, title: editingTitle.trim() });
    } else {
      setEditingSessionId(null);
      setEditingTitle('');
    }
  };

  const handleTitleKeyDown = (e: React.KeyboardEvent, sessionId: string) => {
    if (e.key === 'Enter') {
      handleTitleSubmit(sessionId);
    } else if (e.key === 'Escape') {
      setEditingSessionId(null);
      setEditingTitle('');
    }
  };

  const handleSessionSelect = (sessionId: string) => {
    onSessionSelect(sessionId);
    onMobileClose?.();
  };

  const handleNewChat = () => {
    onNewChat();
    onMobileClose?.();
  };

  return (
    <div 
      className={`${isCollapsed ? 'w-16' : 'w-80'} transition-all duration-300 ease-out flex flex-col h-full sidebar-container relative overflow-hidden`}
    >
      {/* Floating lava bubbles */}
      <div className="lava-bubble"></div>
      <div className="lava-bubble"></div>
      <div className="lava-bubble"></div>

      {/* Header */}
      <div className="p-4 sidebar-header bg-white/5 backdrop-blur-sm border-b border-white/10">
        <div className="flex items-center justify-between relative">
          {!isCollapsed && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                <span className="text-white font-semibold text-sm">SK</span>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-white">Sai Kaki</h2>
                <p className="text-xs text-white/60">AI Assistant</p>
              </div>
            </div>
          )}
          {isCollapsed && (
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center mx-auto">
              <span className="text-white font-semibold text-sm">SK</span>
            </div>
          )}
          {!isMobile && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsCollapsed(!isCollapsed)}
              className={`p-2 bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-all duration-200 rounded-lg border-0 shadow-none z-20 ${isCollapsed ? 'absolute top-1/2 -translate-y-1/2 right-2' : 'ml-auto'}`}
              data-testid="button-collapse-sidebar"
            >
              {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            </Button>
          )}
        </div>
      </div>

      {/* Search Input */}
      {!isCollapsed && (
        <div className="p-4 pt-2">
          <div className="search-input-container relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/60 z-10" />
            <Input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-10 text-white placeholder:text-white/50 focus:ring-0 focus:outline-none rounded-xl relative z-10"
            />
            {searchQuery && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 h-6 w-6 text-white/50 hover:text-white hover:bg-white/10 rounded z-10"
              >
                ×
              </Button>
            )}
          </div>
        </div>
      )}

      {/* New Chat Button */}
      <div className="p-4 pt-2">
        <Button
          onClick={handleNewChat}
          className={`w-full h-11 bg-white/10 backdrop-blur-sm border border-white/20 text-white transition-all duration-200 rounded-xl hover:bg-white/15 hover:scale-[1.01] ${isCollapsed ? 'flex items-center justify-center' : ''}`}
          data-testid="button-new-chat"
        >
          <Plus className={`h-4 w-4 ${isCollapsed ? '' : 'mr-2'}`} />
          {!isCollapsed && <span className="font-medium">New Chat</span>}
        </Button>
      </div>

      {/* Chat History */}
      <div className="flex-1 px-4">
        {!isCollapsed && displayedSessions.length > 0 && (
          <div className="mb-3">
            <h3 className="text-xs font-medium text-white/60 mb-2">Recent Chats</h3>
            <div className="h-px bg-white/10" />
          </div>
        )}

        <ScrollArea className="h-full">
          <div className="space-y-2 pb-4">
            {displayedSessions.map((session: ChatSession, index) => (
              <div
                key={session.id}
                className={`group relative rounded-xl p-3 cursor-pointer transition-all duration-200 ${
                  currentSessionId === session.id 
                    ? 'bg-white/15 backdrop-blur-sm border border-white/20 text-white' 
                    : 'text-white/80 hover:text-white hover:bg-white/10 backdrop-blur-sm'
                }`}
                onClick={() => handleSessionSelect(session.id)}
                data-testid={`chat-session-${session.id}`}
              >
                <div className={`flex items-start ${isCollapsed ? 'justify-center' : 'space-x-3'}`}>
                  <div className={`p-1.5 rounded-md flex-shrink-0 ${
                    currentSessionId === session.id 
                      ? 'bg-white/20' 
                      : 'bg-white/10'
                  }`}>
                    <MessageSquare className="h-4 w-4" />
                  </div>

                  {!isCollapsed && (
                    <div className="flex-1 min-w-0">
                      {editingSessionId === session.id ? (
                        <Input
                          value={editingTitle}
                          onChange={(e) => setEditingTitle(e.target.value)}
                          onBlur={() => handleTitleSubmit(session.id)}
                          onKeyDown={(e) => handleTitleKeyDown(e, session.id)}
                          className="text-sm font-medium bg-white/10 backdrop-blur-sm border-white/30 text-white focus:border-white/50 h-8 px-2 rounded-lg"
                          autoFocus
                          onClick={(e) => e.stopPropagation()}
                        />
                      ) : (
                        <div 
                          className="text-sm font-medium truncate cursor-pointer hover:text-blue-300 transition-colors duration-200 mb-1"
                          onClick={(e) => handleTitleClick(session, e)}
                          title="Click to rename"
                        >
                          {formatChatTitle(session.title)}
                        </div>
                      )}
                      <div className="text-xs text-white/50 flex items-center space-x-2">
                        <span>{formatDate(session.updatedAt?.toString() || session.createdAt?.toString() || null)}</span>
                        {currentSessionId === session.id && (
                          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {!isCollapsed && (
                  <div className="absolute right-3 top-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-2 group-hover:translate-x-0">
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          downloadChat(session.id, session.title);
                        }}
                        className="p-1.5 h-7 w-7 hover:bg-white/20 hover:text-blue-300 transition-all duration-200 hover:scale-110 active:scale-95 rounded-lg backdrop-blur-sm"
                        title="Download Chat"
                        data-testid={`button-download-${session.id}`}
                      >
                        <Download className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteSessionMutation.mutate(session.id);
                        }}
                        className="p-1.5 h-7 w-7 hover:bg-white/20 hover:text-red-300 transition-all duration-200 hover:scale-110 active:scale-95 rounded-lg backdrop-blur-sm"
                        title="Delete Chat"
                        data-testid={`button-delete-${session.id}`}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {displayedSessions.length === 0 && !isCollapsed && (
              <div className="text-center py-8">
                <MessageSquare className="h-12 w-12 text-white/20 mx-auto mb-3" />
                <p className="text-white/40 text-sm">No conversations yet</p>
                <p className="text-white/30 text-xs mt-1">Start a new chat to begin</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* User Info & Settings */}
      <div className="relative p-4 border-t border-white/10 space-y-3 sidebar-footer bg-white/5 backdrop-blur-sm">
        {/* User Info */}
        {!isCollapsed && (
          <div className="flex items-center space-x-3 p-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 transition-all duration-200">
            <img 
              src={user?.profilePicture || localStorage.getItem('user_profile_picture') || '/guest-profile-new.png'} 
              alt={user?.username || 'User'}
              className="w-8 h-8 rounded-lg object-cover"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                if (target.src.includes('guest-profile-new.png')) {
                  target.src = '/guest-profile.png';
                } else if (target.src.includes('guest-profile.png')) {
                  target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='6' fill='%23ffffff20'/%3E%3Ctext x='16' y='20' text-anchor='middle' fill='white' font-size='12' font-weight='500'%3EHI%3C/text%3E%3C/svg%3E";
                }
              }}
            />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white truncate">
                {user.username}
              </div>
              <div className="text-xs text-white/60 truncate">
                {user.email}
              </div>
            </div>
          </div>
        )}

        <Button
          variant="ghost"
          onClick={onSettingsClick}
          className={`w-full h-10 text-white/80 hover:text-white bg-white/10 hover:bg-white/15 backdrop-blur-sm border border-white/20 rounded-xl transition-all duration-200 ${isCollapsed ? 'justify-center' : 'justify-start'}`}
          data-testid="button-settings"
        >
          <Settings className={`h-4 w-4 ${isCollapsed ? '' : 'mr-2'}`} />
          {!isCollapsed && <span className="font-medium">Settings</span>}
        </Button>
      </div>
    </div>
  );
}

export default function Sidebar(props: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const isMobile = useIsMobile();

  // Auto-collapse on mobile
  useEffect(() => {
    if (isMobile) {
      setIsCollapsed(true);
    }
  }, [isMobile]);

  if (isMobile) {
    return (
      <>
        {/* Mobile Trigger Button */}
        <div className="mobile-sidebar-trigger">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="p-3 bg-purple-500/20 hover:bg-purple-500/30 backdrop-blur-sm text-white border border-white/20 rounded-lg shadow-lg transition-all duration-200 hover:scale-105"
                data-testid="mobile-sidebar-trigger"
                onClick={() => setMobileOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent 
              side="left" 
              className="p-0 w-80 border-r-0 touch-pan-y"
              onInteractOutside={() => setMobileOpen(false)}
              onEscapeKeyDown={() => setMobileOpen(false)}
              onPointerDownOutside={() => setMobileOpen(false)}
            >
              <SidebarContent
                {...props}
                isCollapsed={false}
                setIsCollapsed={() => {}}
                onMobileClose={() => setMobileOpen(false)}
              />
            </SheetContent>
          </Sheet>
        </div>
      </>
    );
  }

  return (
    <div className={props.className}>
      <SidebarContent
        {...props}
        isCollapsed={isCollapsed}
        setIsCollapsed={setIsCollapsed}
      />
    </div>
  );
}
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { User } from 'lucide-react';

interface LoginPageProps {
  onLogin: (token: string, user: any) => void;
  onGuestLogin?: () => void;
}

declare global {
  interface Window {
    google: any;
  }
}

export default function LoginPage({ onLogin, onGuestLogin }: LoginPageProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [guestLoading, setGuestLoading] = useState(false);
  const { toast } = useToast();

  const handleGuestLogin = async () => {
    setGuestLoading(true);
    try {
      // Create a guest user
      const guestUser = {
        id: 'guest-' + Date.now(),
        username: 'Guest User',
        email: 'guest@saikaki.ai',
        isGuest: true
      };

      // Store guest user data locally without requiring a token
      localStorage.setItem('guest_user', JSON.stringify(guestUser));

      // Call onGuestLogin if available, otherwise use onLogin with null token
      if (onGuestLogin) {
        onGuestLogin();
      } else {
        onLogin(null, guestUser);
      }
    } catch (error) {
      console.error('Guest login error:', error);
      toast({
        title: "Guest Login Failed",
        description: "Could not create guest session. Please try again.",
        variant: "destructive",
      });
    } finally {
      setGuestLoading(false);
    }
  };

  // Debug environment variables
  console.log('VITE_GOOGLE_CLIENT_ID:', import.meta.env.VITE_GOOGLE_CLIENT_ID);
  console.log('All env vars:', import.meta.env);

  const handleGoogleLogin = async (credentialResponse: any) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/google', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          token: credentialResponse.credential,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        // Store the token and profile picture
        localStorage.setItem('auth_token', data.token);
        if (data.user.profilePicture) {
          console.log('Storing profile picture:', data.user.profilePicture);
          localStorage.setItem('user_profile_picture', data.user.profilePicture);
        }

        // Store user data for onboarding check and personalized greetings
        console.log('Storing user data:', data.user);
        localStorage.setItem('user_data', JSON.stringify(data.user));
        onLogin(data.token, data.user);
      } else {
        throw new Error('Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: "Login Failed",
        description: "Could not log in with Google. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const initializeGoogleSignIn = () => {
    const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID;

    if (window.google && clientId) {
      console.log('Current URL:', window.location.origin);
      console.log('Initializing Google Sign-In with Client ID:', clientId);

      window.google.accounts.id.initialize({
        client_id: clientId,
        callback: handleGoogleLogin,
        auto_select: false,
        cancel_on_tap_outside: false,
        ux_mode: 'popup', // Use popup mode for better compatibility
      });

      window.google.accounts.id.renderButton(
        document.getElementById("google-signin-button"),
        {
          theme: "filled_blue",
          size: "large",
          text: "signin_with",
          shape: "rectangular",
        }
      );
    } else {
      console.error('Google Client ID not found in environment variables');
      console.error('Available env vars:', import.meta.env);
    }
  };

  // Load Google Sign-In script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.onload = initializeGoogleSignIn;
    document.body.appendChild(script);

    return () => {
      const existingScript = document.querySelector('script[src="https://accounts.google.com/gsi/client"]');
      if (existingScript) {
        document.body.removeChild(existingScript);
      }
    };
  }, []);

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center px-4">
      {/* Mountain landscape background */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-300 via-purple-400 to-purple-900">
        {/* Sky gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-blue-200 via-purple-200 to-transparent opacity-60"></div>

        {/* Mountain layers */}
        <div className="absolute bottom-0 left-0 right-0">
          {/* Back mountains */}
          <svg className="absolute bottom-0 w-full h-96" viewBox="0 0 1200 400" fill="none">
            <path d="M0 400L200 200L400 250L600 150L800 200L1000 180L1200 220V400H0Z" fill="rgba(139, 69, 219, 0.4)"/>
            <path d="M0 400L150 280L350 300L550 220L750 260L950 240L1200 280V400H0Z" fill="rgba(139, 69, 219, 0.6)"/>
            <path d="M0 400L100 320L300 340L500 280L700 310L900 300L1200 320V400H0Z" fill="rgba(139, 69, 219, 0.8)"/>
          </svg>

          {/* Front mountains with forest silhouette */}
          <svg className="absolute bottom-0 w-full h-64" viewBox="0 0 1200 200" fill="none">
            <path d="M0 200L50 150L100 160L150 140L200 155L250 145L300 165L350 150L400 170L450 155L500 175L550 160L600 180L650 165L700 185L750 170L800 190L850 175L900 195L950 180L1000 200L1050 185L1100 205L1150 190L1200 210V200H0Z" fill="rgba(88, 28, 135, 0.9)"/>
          </svg>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
            <span className="text-2xl font-bold text-white">SK</span>
          </div>
          <h1 className="text-4xl font-bold text-white mb-2 drop-shadow-lg">
            Welcome to Sai Kaki
          </h1>
          <p className="text-white/90 text-lg drop-shadow">
            Your AI assistant with attitude. Sign in to get started.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20 shadow-2xl">
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-white mb-6">
                Choose how to continue
              </h2>

              <div className="space-y-4">
                <div id="google-signin-button" className="flex justify-center"></div>

                {isLoading && (
                  <div className="text-white/80 flex items-center justify-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Signing you in...</span>
                  </div>
                )}

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-white/30"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-transparent text-white/70">or</span>
                  </div>
                </div>

                <Button
                  onClick={handleGuestLogin}
                  variant="outline"
                  className="w-full py-3 border-2 border-white/30 text-white bg-white/10 hover:bg-white/20 hover:border-white/50 transition-all duration-200 backdrop-blur-sm"
                  disabled={guestLoading}
                >
                  {guestLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Creating guest session...</span>
                    </div>
                  ) : (
                    <>
                      <User className="h-5 w-5 mr-2" />
                      Continue as Guest
                    </>
                  )}
                </Button>
              </div>
            </div>

            <div className="text-center text-sm text-white/70">
              <p>
                By continuing, you agree to our terms of service and privacy policy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { Send, Mic, MicOff } from "lucide-react";
import { useGeolocation } from "@/hooks/use-geolocation";
import type { ChatMessage } from "../../shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";


interface ChatResponse {
  userMessage: ChatMessage;
  aiMessage: ChatMessage;
}

interface ChatProps {
  currentSessionId: string | null;
  onSessionCreated: (sessionId: string) => void;
}

export default function Chat({ currentSessionId, onSessionCreated }: ChatProps) {
  const [messageInput, setMessageInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [guestMessages, setGuestMessages] = useState<ChatMessage[]>([]);
  const recognitionInstanceRef = useRef<any>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null); // Ref for the scroll anchor
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const geolocation = useGeolocation();

  // Typewriter effect state and logic
  const phrases = [
    "Ask me anything...",
    "What's on your mind?",
    "Need help with code?",
    "Let's chat!",
    "Tell me a joke...",
  ];
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [placeholderText, setPlaceholderText] = useState("");

  useEffect(() => {
    const typewriter = () => {
      const currentPhrase = phrases[currentPhraseIndex];
      if (isDeleting) {
        setPlaceholderText(currentPhrase.substring(0, currentCharIndex - 1));
        setCurrentCharIndex(currentCharIndex - 1);
        if (currentCharIndex === 1) {
          setIsDeleting(false);
          setCurrentPhraseIndex((currentPhraseIndex + 1) % phrases.length);
        }
      } else {
        setPlaceholderText(currentPhrase.substring(0, currentCharIndex + 1));
        setCurrentCharIndex(currentCharIndex + 1);
        if (currentCharIndex === currentPhrase.length) {
          setTimeout(() => setIsDeleting(true), 1000); // Shorter pause before backspacing
        }
      }
    };

    // Different speeds for typing vs deleting for smoother feel
    const speed = isDeleting ? 50 : 80; // Faster typing, even faster deleting
    const typingInterval = setInterval(typewriter, speed);

    return () => clearInterval(typingInterval);
  }, [currentPhraseIndex, currentCharIndex, isDeleting, phrases]);


  // Check if user is guest
  const isGuest = !localStorage.getItem('auth_token') && localStorage.getItem('guest_user');

  // Fetch messages for current session
  const { data: messages = [] } = useQuery({
    queryKey: ['/api/chat/sessions', currentSessionId, 'messages'],
    queryFn: async () => {
      if (!currentSessionId) return [];

      const token = localStorage.getItem('auth_token');
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`/api/chat/sessions/${currentSessionId}/messages`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.status === 401) {
        // Token expired or invalid, clear storage and reload
        localStorage.removeItem('auth_token');
        localStorage.removeItem('user_profile_picture');
        window.location.reload();
        return [];
      }

      if (!response.ok) throw new Error('Failed to fetch messages');
      return response.json();
    },
    enabled: !!currentSessionId && !isGuest,
    retry: (failureCount, error) => {
      // Don't retry on auth errors
      if (error.message.includes('authentication')) return false;
      return failureCount < 3;
    }
  });

  // Welcome message for new chats
  const welcomeMessage = {
    id: 'welcome',
    sessionId: 'welcome',
    role: 'assistant' as const,
    content: '# Welcome to Sai Kaki v0.1\n\nHey there! I\'m Sai Kaki, your AI assistant with a bit of attitude. I can help you with questions, provide real-time information, play chess, and even analyze images. What would you like to know?',
    createdAt: new Date().toISOString()
  };

  const displayMessages = isGuest ?
    (guestMessages.length > 0 ? guestMessages : [welcomeMessage]) :
    (currentSessionId ? messages : [welcomeMessage]);

  // Debug function to check image loading
  const checkImageExists = (src: string) => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(true);
      img.onerror = () => resolve(false);
      img.src = src;
    });
  };

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition(); // Changed recognitionInstance to recognition
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setMessageInput(transcript);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        toast({
          title: "Speech Recognition Error",
          description: "Could not recognize speech. Please try again.",
          variant: "destructive"
        });
      };

      // Store the instance in the ref
      recognitionInstanceRef.current = recognition;
    }
  }, [toast]);

  // Scroll to the bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [displayMessages]); // Depend on displayMessages to trigger scroll

  const createNewSession = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch('/api/chat/sessions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title: 'New Chat' })
      });

      if (response.status === 401) {
        // Token expired or invalid, clear storage and reload
        localStorage.removeItem('auth_token');
        localStorage.removeItem('user_profile_picture');
        toast({
          title: "Session Expired",
          description: "Please sign in again to continue.",
          variant: "destructive"
        });
        window.location.reload();
        return null;
      }

      if (response.ok) {
        const session = await response.json();
        onSessionCreated(session.id);
        return session.id;
      } else {
        throw new Error(`Failed to create session: ${response.status}`);
      }
    } catch (error) {
      console.error('Failed to create session:', error);
      toast({
        title: "Error",
        description: "Failed to create new session. Please try again.",
        variant: "destructive"
      });
    }
    return null;
  };

  const requestLocationIfNeeded = async (message: string) => {
    const locationKeywords = ['nearest', 'nearby', 'closest', 'mcdonald', 'restaurant', 'gas station', 'hospital'];
    const needsLocation = locationKeywords.some(keyword =>
      message.toLowerCase().includes(keyword)
    );

    if (needsLocation && !geolocation.data) {
      await geolocation.requestPermission();
    }
  };

  const handleVoiceInput = () => {
    const recognition = recognitionInstanceRef.current; // Use the ref's current value
    if (!recognition) {
      toast({
        title: "Speech Recognition Not Available",
        description: "Your browser doesn't support speech recognition.",
        variant: "destructive"
      });
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.start();
      setIsListening(true);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || isTyping) return;

    const messageContent = messageInput.trim();
    setMessageInput(""); // Clear input after getting the message
    setIsTyping(true);

    await requestLocationIfNeeded(messageContent);

    try {
      if (isGuest) {
        // Handle guest mode locally
        const userMessage: ChatMessage = {
          id: 'guest-user-' + Date.now(),
          sessionId: 'guest-session',
          role: 'user',
          content: messageContent,
          createdAt: new Date().toISOString()
        };

        // Generate a simple AI response for guest mode
        const generateGuestResponse = (userInput: string): string => {
          const input = userInput.toLowerCase();

          // Handle common queries with basic responses
          if (input.includes('hello') || input.includes('hi') || input.includes('hey')) {
            return "Hey there! 👋 I'm Sai Kaki running in limited guest mode. I can chat with you, but for my full AI capabilities with real-time data and sarcastic wit, please sign in with Google! What's on your mind?";
          }

          if (input.includes('how are you') || input.includes('how do you do')) {
            return "I'm doing great, thanks for asking! 😊 Though I'm running in guest mode, so I'm like a sports car in first gear - functional but not at full power. Sign in for the complete experience!";
          }

          if (input.includes('what can you do')) {
            return "In guest mode, I can have basic conversations with you! 💬 But when you sign in with Google, I become much more powerful - I can provide real-time data, search the web, analyze images, play chess, and serve up responses with my signature sarcastic attitude! 🤖✨";
          }

          if (input.includes('time') || input.includes('date')) {
            const now = new Date();
            return `It's currently ${now.toLocaleTimeString()} on ${now.toLocaleDateString()}! ⏰ This is about all I can tell you in guest mode. Sign in for location-based time and much more!`;
          }

          if (input.includes('joke') || input.includes('funny')) {
            return "Here's a tech joke for you: Why do programmers prefer dark mode? Because light attracts bugs! 😄 For better humor and wit, sign in for my full personality!";
          }

          // Default response with some variation
          const responses = [
            `Interesting question about "${userInput}"! 🤔 In guest mode, I can only give basic responses. For detailed, witty, and informative answers, please sign in with Google!`,
            `You asked: "${userInput}" - I'd love to give you a brilliant response! But I'm in guest mode right now. Sign in to unlock my full potential! 🚀`,
            `That's a great question! "${userInput}" deserves a proper answer with my full AI capabilities. Sign in with Google to get the complete Sai Kaki experience! ✨`
          ];

          return responses[Math.floor(Math.random() * responses.length)];
        };

        const aiMessage: ChatMessage = {
          id: 'guest-ai-' + Date.now(),
          sessionId: 'guest-session',
          role: 'assistant',
          content: generateGuestResponse(messageContent),
          createdAt: new Date().toISOString()
        };

        setGuestMessages(prev => [...prev, userMessage, aiMessage]);
      } else {
        // Handle authenticated mode
        let sessionId = currentSessionId;
        if (!sessionId) {
          sessionId = await createNewSession();
          if (!sessionId) {
            throw new Error('Failed to create session');
          }
        }

        const token = localStorage.getItem('auth_token');
        if (!token) {
          throw new Error('No authentication token found');
        }

        // Get user's name for personalized greeting
        const storedUserData = localStorage.getItem('user_data');
        let userName = '';
        if (storedUserData) {
          try {
            const userData = JSON.parse(storedUserData);
            userName = userData.username || '';
            console.log('Sending user name for greeting:', userName);
          } catch (e) {
            console.error('Error parsing user data:', e);
          }
        }

        // Check if this is the first message in the session for personalized greeting
        const isFirstMessage = !currentSessionId || (currentSessionId && messages.length === 0);
        console.log('Is first message:', isFirstMessage, 'Session ID:', sessionId, 'Messages length:', messages.length);

        const response = await fetch(`/api/chat/sessions/${sessionId}/messages`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            content: messageContent,
            role: 'user',
            userLocation: geolocation.data,
            userName: userName,
            isFirstMessage: isFirstMessage
          })
        });

        if (response.status === 401) {
          // Token expired or invalid, clear storage and reload
          localStorage.removeItem('auth_token');
          localStorage.removeItem('user_profile_picture');
          toast({
            title: "Session Expired",
            description: "Please sign in again to continue.",
            variant: "destructive"
          });
          window.location.reload();
          return;
        }

        if (!response.ok) {
          const errorData = await response.text();
          console.error('Server error:', errorData);
          throw new Error(`Server responded with ${response.status}: ${errorData}`);
        }

        const data: ChatResponse = await response.json();

        // Invalidate queries to refresh the UI
        queryClient.invalidateQueries({ queryKey: ['/api/chat/sessions'] });
        queryClient.invalidateQueries({ queryKey: ['/api/chat/sessions', sessionId, 'messages'] });
      }

    } catch (error) {
      console.error('Chat error:', error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any); // Cast to any to satisfy onSubmit signature
    }
  };

  const formatMessage = (content: string) => {
    return content.split('\n').map((line, index) => (
      <span key={index}>
        {line}
        {index < content.split('\n').length - 1 && <br />}
      </span>
    ));
  };



  return (
    <div className="chat-container flex flex-col h-screen text-white relative" style={{ backgroundColor: '#212121' }}>
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col relative z-10" style={{ backgroundColor: '#212121' }}>
        {displayMessages.length === 0 || ((!currentSessionId && !isGuest) && displayMessages.length === 1) ? (
          // Welcome/Empty State
          <div className="flex-1 flex flex-col items-center justify-center px-4">
            <div className="w-full max-w-2xl">
              <h1 className="text-4xl md:text-5xl font-light text-center text-white mb-12">
                SAI KAKI 0.1
              </h1>

              {/* Input Form */}
              <form onSubmit={handleSubmit} className="relative">
                <div className="relative rounded-full modern-input-container" style={{ backgroundColor: '#303030' }}>
                  <div className="flex items-center pl-4 pr-2 py-2">
                    <div className="flex-1 flex items-center space-x-2">
                      <span className="text-gray-400 text-sm">+</span>
                      <Textarea
                        ref={textareaRef}
                        value={messageInput}
                        onChange={(e) => setMessageInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder={placeholderText || "Ask anything"}
                        className="flex-1 bg-transparent border-none resize-none text-white placeholder-gray-400 focus:outline-none focus:ring-0 min-h-[40px] max-h-32 py-2"
                        style={{ fieldSizing: 'content' } as any}
                        disabled={isTyping}
                      />
                    </div>

                    <div className="flex items-center space-x-3 ml-4">
                      {recognitionInstanceRef.current && ( // Check if recognition is available
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={handleVoiceInput}
                          className={`w-10 h-10 rounded-full voice-button ${
                            isListening ? 'listening' : ''
                          }`}
                        >
                          {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                        </Button>
                      )}

                      <Button
                        type="submit"
                        size="sm"
                        disabled={!messageInput.trim() || isTyping}
                        className="w-10 h-10 neon-button disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        ) : (
          // Chat Messages
          <div className="flex-1 p-4 space-y-4 message-container relative z-20" style={{ backgroundColor: 'rgba(42, 42, 42, 1)', backdropFilter: 'blur(10px)' }}>
            <div className="max-w-4xl mx-auto space-y-6">
              {displayMessages.map((message) => (
                <div
                  key={message.id}
                  className="flex justify-start"
                >
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0 mt-1">
                      {message.role === 'assistant' ? (
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
                          <img
                            src="/ai-avatar-custom.png"
                            alt="Sai Kaki AI"
                            className="w-full h-full object-cover rounded-full"
                            onError={(e) => {
                              console.log('AI avatar failed to load, using fallback');
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                              target.parentElement!.innerHTML = '<span class="text-white text-sm font-bold">AI</span>';
                            }}
                          />
                        </div>
                      ) : (
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                          <img
                            src={isGuest ? '/guest-profile-new.png' : (localStorage.getItem('user_profile_picture') || '/guest-profile-new.png')}
                            alt={isGuest ? 'Guest User' : 'User'}
                            className="w-full h-full object-cover rounded-full"
                            onError={(e) => {
                              console.log('User avatar failed to load, using fallback');
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                              target.parentElement!.innerHTML = `<span class="text-white text-sm font-bold">${isGuest ? 'GU' : 'US'}</span>`;
                            }}
                          />
                        </div>
                      )}
                    </div>
                    <div
                      className={`max-w-xs md:max-w-2xl px-4 py-3 rounded-2xl ${
                        message.role === 'user'
                          ? 'bg-gradient-to-br from-cyan-400 to-blue-600 text-white shadow-lg shadow-cyan-500/25'
                          : 'bg-purple-600/30 text-purple-100 border border-purple-400/40 backdrop-blur-sm'
                      }`}
                    >
                      <div className="text-sm leading-relaxed whitespace-pre-wrap">
                        {formatMessage(message.content)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0 mt-1">
                      <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
                        <img
                          src="/ai-avatar-custom.png"
                          alt="Sai Kaki AI"
                          className="w-full h-full object-cover rounded-full"
                          onError={(e) => {
                            console.log('AI avatar (typing) failed to load, using fallback');
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            target.parentElement!.innerHTML = '<span class="text-white text-sm font-bold">AI</span>';
                          }}
                        />
                      </div>
                    </div>
                    <div className="bg-purple-600/30 text-purple-100 border border-purple-400/40 backdrop-blur-sm px-4 py-3 rounded-2xl">
                      <div className="flex space-x-2">
                        <div className="w-2 h-2 bg-purple-300 rounded-full animate-pulse"></div>
                        <div className="w-2 h-2 bg-purple-300 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                        <div className="w-2 h-2 bg-purple-300 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {/* Scroll anchor */}
              <div ref={messagesEndRef} />
            </div>
          </div>
        )}

        {/* Bottom Input - Only show when there are messages */}
        {((currentSessionId && displayMessages.length > 0) || (isGuest && displayMessages.length > 0)) && (
          <div className="border-t border-gray-800 px-4 py-4 bg-transparent relative z-30">
            <div className="max-w-4xl mx-auto">
              <form onSubmit={handleSubmit}>
                <div className="relative rounded-full modern-input-container" style={{ backgroundColor: '#303030' }}>
                  <div className="flex items-center pl-4 pr-2 py-2">
                    <Textarea
                      ref={textareaRef}
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder={placeholderText || "Ask anything"}
                      className="flex-1 bg-transparent border-none resize-none text-white placeholder-gray-400 focus:outline-none focus:ring-0 min-h-[40px] max-h-32 py-2"
                      style={{ fieldSizing: 'content' } as any}
                      disabled={isTyping}
                    />

                    <div className="flex items-center space-x-3 ml-4">
                      {recognitionInstanceRef.current && ( // Check if recognition is available
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={handleVoiceInput}
                          className={`w-10 h-10 rounded-full voice-button ${
                            isListening ? 'listening' : ''
                          }`}
                        >
                          {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                        </Button>
                      )}

                      <Button
                        type="submit"
                        size="sm"
                        disabled={!messageInput.trim() || isTyping}
                        className="w-10 h-10 neon-button disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatSessionSchema, insertChatMessageSchema } from "@shared/schema";
import { generateSarcasticResponse, generateSarcasticResponseStream, filterPersonalInformation } from "./services/openai";
import { enhanceResponseWithWebData } from "./services/websearch";
import { analyzeImage, generateImage, formatImageAnalysisForAI } from "./services/vision";
import multer from "multer";
import { z } from "zod";
import jwt from "jsonwebtoken";
import { OAuth2Client } from "google-auth-library";

export async function registerRoutes(app: Express): Promise<Server> {

  // Trust proxy to get real IP addresses
  app.set('trust proxy', true);

  // Google OAuth client
  const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

  // Authentication middleware
  const authenticateUser = async (req: any, res: any, next: any) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'No token provided' });
      }

      const token = authHeader.substring(7);
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret') as any;
      req.user = decoded;
      next();
    } catch (error) {
      return res.status(401).json({ error: 'Invalid token' });
    }
  };

  // Google OAuth login
  app.post("/api/auth/google", async (req, res) => {
    try {
      const { token } = req.body;
      const ticket = await client.verifyIdToken({
        idToken: token,
        audience: process.env.GOOGLE_CLIENT_ID,
      });

      const payload = ticket.getPayload();
      if (!payload) {
        return res.status(400).json({ error: 'Invalid Google token' });
      }

      // Create or get user
      let user = await storage.getUserByEmail(payload.email!);
      if (!user) {
        user = await storage.createUser({
          username: payload.name!,
          email: payload.email!,
          profilePicture: payload.picture,
        });
      }

      // Generate JWT
      const jwtToken = jwt.sign(
        { userId: user.id, email: user.email, name: user.username },
        process.env.JWT_SECRET || 'fallback-secret',
        { expiresIn: '7d' }
      );

      res.json({ token: jwtToken, user });
    } catch (error) {
      console.error('Google auth error:', error);
      res.status(500).json({ error: 'Authentication failed' });
    }
  });

  // Get current user
  app.get("/api/auth/me", authenticateUser, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get user' });
    }
  });

  // Update privacy policy acceptance
  app.post("/api/auth/privacy-accepted", authenticateUser, async (req: any, res) => {
    try {
      await storage.updateUser(req.user.userId, { privacyPolicyAccepted: new Date() });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update privacy acceptance' });
    }
  });

  // Clear privacy policy acceptance
  app.delete("/api/auth/privacy-accepted", authenticateUser, async (req: any, res) => {
    try {
      await storage.updateUser(req.user.userId, { privacyPolicyAccepted: null });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to clear privacy acceptance' });
    }
  });

  // Configure multer for file uploads
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB limit
    },
    fileFilter: (req, file, cb) => {
      if (file.mimetype.startsWith('image/')) {
        cb(null, true);
      } else {
        cb(new Error('Only image files are allowed!'), false);
      }
    },
  });

  // Create a new chat session
  app.post("/api/chat/sessions", authenticateUser, async (req: any, res) => {
    try {
      const sessionData = insertChatSessionSchema.parse({
        ...req.body,
        userId: req.user.userId
      });
      const session = await storage.createChatSession(sessionData);
      res.json(session);
    } catch (error) {
      res.status(400).json({ error: "Invalid session data" });
    }
  });

  // Get all chat sessions for a user
  app.get("/api/chat/sessions", authenticateUser, async (req: any, res) => {
    try {
      const sessions = await storage.getUserChatSessions(req.user.userId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  // Search chat sessions
  app.get("/api/chat/sessions/search", authenticateUser, async (req: any, res) => {
    try {
      const { query } = req.query;
      const sessions = await storage.searchUserChatSessions(req.user.userId, query as string);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to search sessions" });
    }
  });

  // Get a specific chat session
  app.get("/api/chat/sessions/:id", authenticateUser, async (req: any, res) => {
    try {
      const session = await storage.getChatSession(req.params.id);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch session" });
    }
  });

  // Delete a chat session
  app.delete("/api/chat/sessions/:id", authenticateUser, async (req: any, res) => {
    try {
      const session = await storage.getChatSession(req.params.id);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }
      const deleted = await storage.deleteChatSession(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete session" });
    }
  });

  // Update chat session title
  app.put("/api/chat/sessions/:id/title", authenticateUser, async (req: any, res) => {
    try {
      const session = await storage.getChatSession(req.params.id);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }

      const { title } = req.body;
      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return res.status(400).json({ error: "Valid title is required" });
      }

      await storage.updateChatSession(req.params.id, { title: title.trim() });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update session title" });
    }
  });

  // Delete all chat sessions for user
  app.delete("/api/chat/sessions", authenticateUser, async (req: any, res) => {
    try {
      await storage.deleteAllUserSessions(req.user.userId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete all sessions" });
    }
  });

  // Get messages for a chat session
  app.get("/api/chat/sessions/:id/messages", authenticateUser, async (req: any, res) => {
    try {
      const session = await storage.getChatSession(req.params.id);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }
      const messages = await storage.getSessionMessages(req.params.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Generate title from message content
  const generateTitleFromMessage = (message: string): string => {
    // Clean the message - keep more characters for better titles
    const cleaned = message.trim().replace(/[^\w\s\?\!\.]/g, '');

    // If message is too short, return default
    if (cleaned.length < 3) {
      return "New Chat";
    }

    // Common greetings and generic phrases
    const genericPhrases = [
      'hi', 'hello', 'hey', 'howdy', 'greetings', 'good morning', 'good afternoon', 
      'good evening', 'good day', 'whats up', 'how are you', 'how do you do',
      'nice to meet you', 'pleased to meet you', 'how are things'
    ];

    const lowerMessage = cleaned.toLowerCase();
    
    // Check if it's a pure greeting
    const isPureGreeting = genericPhrases.some(phrase => {
      const regex = new RegExp(`^${phrase}[\\s\\!\\?]*$`, 'i');
      return regex.test(lowerMessage);
    });

    if (isPureGreeting) {
      return "New Chat";
    }

    // For messages that start with greetings but have more content
    const startsWithGreeting = genericPhrases.some(phrase => 
      lowerMessage.startsWith(phrase + ' ')
    );

    if (startsWithGreeting) {
      // Find the greeting and take the rest
      const greetingMatch = genericPhrases.find(phrase => 
        lowerMessage.startsWith(phrase + ' ')
      );
      if (greetingMatch) {
        const afterGreeting = cleaned.substring(greetingMatch.length).trim();
        if (afterGreeting.length > 5) {
          const truncated = afterGreeting.substring(0, 45);
          const title = truncated.charAt(0).toUpperCase() + truncated.slice(1);
          return afterGreeting.length > 45 ? title + "..." : title;
        }
      }
    }

    // For all other messages, create title from the full content
    const truncated = cleaned.substring(0, 45);
    const title = truncated.charAt(0).toUpperCase() + truncated.slice(1);
    return cleaned.length > 45 ? title + "..." : title;
  };

  // Send a message and get AI response
  app.post("/api/chat/sessions/:id/messages", authenticateUser, async (req: any, res) => {
    try {
      const sessionId = req.params.id;

      // Verify session ownership
      const session = await storage.getChatSession(sessionId);
      if (!session || session.userId !== req.user.userId) {
        return res.status(404).json({ error: "Session not found" });
      }
      const messageSchema = z.object({
        content: z.string().min(1),
        role: z.literal("user"),
        userLocation: z.object({
          lat: z.number(),
          lon: z.number()
        }).optional().nullable(),
        imageUrl: z.string().optional(),
        userName: z.string().optional(),
        isFirstMessage: z.boolean().optional()
      });

      const { content, role, userLocation, imageUrl, userName, isFirstMessage } = messageSchema.parse(req.body);

      let processedContent = content;
      let aiMessageContent = '';

      // Handle image generation requests
      if (content.startsWith('[IMAGE_GENERATION]')) {
        const prompt = content.replace('[IMAGE_GENERATION]', '').trim();

        try {
          console.log(`Starting working image generation for: "${prompt}"`);
          const imageUrl = await generateImage(prompt);
          console.log('Image generation successful with working APIs');

          // Create user message
          const userMessage = await storage.createChatMessage({
            sessionId,
            role: "user",
            content: `Generate an image: ${prompt}`,
          });

          // Create AI message with generated image
          if (imageUrl.includes('unsplash.com')) {
            aiMessageContent = `Here's a stunning photo for "${prompt}"! 📸\n\n![Generated Image](${imageUrl})\n\nFound this gorgeous real photograph that captures your vision perfectly. Sometimes reality beats AI, right? 😏✨`;
          } else if (imageUrl.includes('svg')) {
            aiMessageContent = `Here's your custom "${prompt}" masterpiece! 🎨\n\n![Generated Image](${imageUrl})\n\nCreated this special artwork just for you using advanced vector graphics. It's got that premium hand-crafted feel! 😎✨`;
          } else if (imageUrl.includes('pollinations')) {
            aiMessageContent = `Here's your AI-generated "${prompt}"! 🎨\n\n![Generated Image](${imageUrl})\n\nGenerated using cutting-edge free AI technology. This is what happens when you have the right connections! 😏🔥`;
          } else {
            aiMessageContent = `Here's your "${prompt}" image! 🎨\n\n![Generated Image](${imageUrl})\n\nGenerated using completely free AI services - no subscription needed! Quality art without breaking the bank! 💪✨`;
          }

          const aiMessage = await storage.createChatMessage({
            sessionId,
            role: "assistant",
            content: aiMessageContent,
          });

          // Update session title only if it's still "New Chat"
          const currentSession = await storage.getChatSession(sessionId);
          if (currentSession?.title === "New Chat") {
            const title = generateTitleFromMessage(prompt);
            if (title !== "New Chat") {
              await storage.updateChatSession(sessionId, { title });
            }
          }

          return res.json({ userMessage, aiMessage });
        } catch (error) {
          console.error("All image generation methods failed:", error);

          // Create fallback response with working alternatives
          aiMessageContent = `Hmm, my image generators are being stubborn today! 😅 But don't worry, I've got backup plans:

🎨 **Try these FREE working alternatives:**
1. **Pollinations.ai** - Paste your prompt directly: "${prompt}"
2. **Craiyon.com** - Completely free, no signup needed
3. **Leonardo.ai** - Free tier with amazing quality
4. **Bing Image Creator** - Free with Microsoft account

**Optimized prompt for you:**
"${prompt}, high quality, detailed, vibrant colors, professional photography style, 4K resolution"

These services are working right now and will give you amazing results! Want me to optimize your prompt even further? 🚀`;

          // Create user message
          const userMessage = await storage.createChatMessage({
            sessionId,
            role: "user",
            content: `Generate an image: ${prompt}`,
          });

          // Create AI message with alternatives
          const aiMessage = await storage.createChatMessage({
            sessionId,
            role: "assistant",
            content: aiMessageContent,
          });

          return res.json({ userMessage, aiMessage });
        }
      }

      if (imageUrl) {
        try {
          console.log('Starting image analysis...');
          const analysis = await analyzeImage(imageUrl);
          console.log('Image analysis completed');
          const formattedAnalysis = formatImageAnalysisForAI(analysis, content);
          processedContent = `${formattedAnalysis}`;
        } catch (error) {
          console.error("Image analysis failed:", error);
          processedContent = `I can see you uploaded an image, but my vision circuits are having a moment! 👀 Could you describe what's in the image? I'd love to help analyze it with my wit intact! Original message: ${content}`;
        }
      }

      // Filter personal information from user message
      const filteredContent = await filterPersonalInformation(processedContent);

      // Save user message
      const userMessage = await storage.createChatMessage({
        sessionId,
        role,
        content: filteredContent,
        metadata: { originalLength: content.length, imageUrl: imageUrl }
      });

      // Check if we should update the title
      const existingMessages = await storage.getSessionMessages(sessionId);
      
      // Only update title if it's still "New Chat" and this message warrants a title
      const currentSession = await storage.getChatSession(sessionId);
      if (currentSession?.title === "New Chat") {
        const newTitle = generateTitleFromMessage(filteredContent);
        // Only update if the generated title is not "New Chat" (meaning it's a substantive message)
        if (newTitle !== "New Chat") {
          await storage.updateChatSession(sessionId, { title: newTitle });
        }
      }

      // Get conversation history for context
      const messages = await storage.getSessionMessages(sessionId);
      const conversationHistory = messages.slice(-10).map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      // Get user's IP address for location-based real-time data
      const userIP = req.ip || req.socket?.remoteAddress ||
                     req.connection?.remoteAddress || '127.0.0.1';

      // Prepare user context for personalized responses
      const userContext = {
        userName: userName || req.user.name || '',
        isFirstMessage: isFirstMessage || false,
        isNewConversation: existingMessages.length <= 1
      };
      console.log('User name for greeting:', userContext.userName);

      // Generate AI response with real-time data and user context
      let aiResponse = await generateSarcasticResponse(filteredContent, conversationHistory, userIP, userLocation, userContext);

      // Enhance with web data if needed
      aiResponse = await enhanceResponseWithWebData(filteredContent, aiResponse);

      // Save AI message
      const aiMessage = await storage.createChatMessage({
        sessionId,
        role: "assistant",
        content: aiResponse,
        metadata: {
          userMessageId: userMessage.id,
          enhanced: aiResponse.includes("*Real-time info")
        }
      });

      // Update session timestamp
      await storage.updateChatSession(sessionId, {});

      res.json({
        userMessage,
        aiMessage
      });
    } catch (error) {
      console.error("Chat error:", error);

      // Generate a sarcastic error response
      const errorMessage = await storage.createChatMessage({
        sessionId: req.params.id,
        role: "assistant",
        content: "Oops! Even I can't fix that mess. My circuits are having a moment. Try again, genius. 🤖💥",
        metadata: { error: true }
      });

      res.status(500).json({
        error: "Failed to process message",
        aiMessage: errorMessage
      });
    }
  });

  // Route to handle image uploads for analysis
  app.post("/api/chat/upload-image", upload.single('image'), async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file uploaded.' });
    }

    try {
      const imageBase64 = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
      const analysis = await analyzeImage(imageBase64);
      const formattedAnalysis = formatImageAnalysisForAI(analysis, '');
      res.json({ analysis: formattedAnalysis });
    } catch (error) {
      console.error("Image upload and analysis failed:", error);
      res.status(500).json({ error: 'Failed to analyze image.' });
    }
  });

  // Route to handle image generation
  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt } = z.object({ prompt: z.string().min(1) }).parse(req.body);

      const imageUrl = await generateImage(prompt);
      res.json({ imageUrl });
    } catch (error) {
      console.error("Image generation failed:", error);
      res.status(500).json({ error: 'Failed to generate image.' });
    }
  });

  // Route to handle messages with images
  app.post("/api/chat/sessions/:id/messages-with-image", upload.single('image'), async (req, res) => {
    try {
      const sessionId = req.params.id;
      const { content, role, userLocation } = req.body;

      if (!req.file) {
        return res.status(400).json({ error: 'No image file uploaded.' });
      }

      // Analyze the uploaded image
      const imageBase64 = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
      let imageAnalysis = '';

      try {
        imageAnalysis = await analyzeImage(imageBase64);
      } catch (error) {
        console.error("Image analysis failed:", error);
        imageAnalysis = "I can see an image, but I'm having trouble analyzing it right now.";
      }

      // Create user message with image context and store image data
      const userMessage = await storage.createChatMessage({
        sessionId,
        role: "user",
        content: content || "Image uploaded",
        metadata: { 
          imageUrl: imageBase64,
          imageAnalysis: imageAnalysis
        }
      });

      // Generate AI response with image context
      const contextualPrompt = formatImageAnalysisForAI(imageAnalysis, content || "");

      // Get conversation history for context
      const sessionMessages = await storage.getSessionMessages(sessionId);
      const conversationHistory = sessionMessages.slice(-10).map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      // Get user's IP address for location-based real-time data
      const userIP = req.ip || req.socket?.remoteAddress ||
                     req.connection?.remoteAddress || '127.0.0.1';

      let aiResponse = '';
      try {
        aiResponse = await generateSarcasticResponse(contextualPrompt, conversationHistory, userIP, userLocation ? JSON.parse(userLocation) : undefined);
      } catch (error) {
        console.error("AI response generation failed:", error);
        aiResponse = "Well, I saw your image but my brain circuits are having a moment. That's embarrassing! 😅";
      }

      const aiMessage = await storage.createChatMessage({
        sessionId,
        role: "assistant", 
        content: aiResponse,
      });

      // Update session title only if it's still "New Chat"
      const currentSession = await storage.getChatSession(sessionId);
      if (currentSession?.title === "New Chat") {
        const title = generateTitleFromMessage(content || "Image uploaded");
        if (title !== "New Chat") {
          await storage.updateChatSession(sessionId, { title });
        }
      }

      res.json({ userMessage, aiMessage });
    } catch (error) {
      console.error("Message with image failed:", error);
      res.status(500).json({ error: 'Failed to process message with image.' });
    }
  });

  // Regenerate last AI message
  app.post("/api/chat/sessions/:id/regenerate", async (req, res) => {
    try {
      const sessionId = req.params.id;
      const messages = await storage.getSessionMessages(sessionId);

      if (messages.length < 2) {
        return res.status(400).json({ error: "No message to regenerate" });
      }

      // Get the last user message
      const lastUserMessage = messages
        .filter(msg => msg.role === "user")
        .pop();

      if (!lastUserMessage) {
        return res.status(400).json({ error: "No user message found" });
      }

      // Get conversation history (excluding the last AI response)
      const conversationHistory = messages
        .slice(0, -1)
        .slice(-10)
        .map(msg => ({
          role: msg.role,
          content: msg.content
        }));

      // Get user's IP address for location-based real-time data
      const userIP = req.ip || req.socket?.remoteAddress ||
                     req.connection?.remoteAddress || '127.0.0.1';

      // Generate new AI response with real-time data (no user location for regeneration)
      let aiResponse = await generateSarcasticResponse(lastUserMessage.content, conversationHistory, userIP, undefined, undefined);
      aiResponse = await enhanceResponseWithWebData(lastUserMessage.content, aiResponse);

      // Save new AI message
      const aiMessage = await storage.createChatMessage({
        sessionId,
        role: "assistant",
        content: aiResponse,
        metadata: {
          regenerated: true,
          originalMessageId: lastUserMessage.id
        }
      });

      res.json(aiMessage);
    } catch (error) {
      console.error("Regenerate error:", error);
      res.status(500).json({ error: "Failed to regenerate message" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}